const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 5000;
const DATA = path.join(__dirname, 'data', 'store.json');
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'frontend')));

function readStore() {
  return JSON.parse(fs.readFileSync(DATA, 'utf8'));
}
function writeStore(data) {
  fs.writeFileSync(DATA, JSON.stringify(data, null, 2));
}
function makeId(prefix) {
  return prefix + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
}

app.get('/api/products', (req, res) => {
  const { q = '', category = 'All' } = req.query;
  let products = readStore().products;
  if (category !== 'All') products = products.filter(p => p.category === category);
  if (q) products = products.filter(p => (p.name + ' ' + p.brand + ' ' + p.description).toLowerCase().includes(q.toLowerCase()));
  res.json(products);
});
app.get('/api/products/:id', (req, res) => {
  const p = readStore().products.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Product not found' });
  res.json(p);
});
app.post('/api/orders', (req, res) => {
  const { customer, items } = req.body;
  if (!customer || !customer.name || !customer.phone || !customer.address || !Array.isArray(items) || !items.length)
    return res.status(400).json({ error: 'Please provide customer details and cart items.' });
  const store = readStore();
  const orderItems = [];
  for (const item of items) {
    const product = store.products.find(p => p.id === item.id);
    const qty = Math.max(1, Math.min(10, Number(item.qty) || 1));
    if (!product || product.stock < qty) return res.status(400).json({ error: `Not enough stock for ${product ? product.name : 'an item'}.` });
    orderItems.push({ id: product.id, name: product.name, price: product.price, qty });
  }
  for (const item of orderItems) {
    const p = store.products.find(x => x.id === item.id);
    p.stock -= item.qty;
  }
  const total = orderItems.reduce((sum, x) => sum + x.price * x.qty, 0);
  const order = { id: makeId('SZ-'), customer, items: orderItems, total, status: 'Order Placed', createdAt: new Date().toISOString() };
  store.orders.unshift(order);
  writeStore(store);
  res.status(201).json({ order });
});
app.get('/api/orders/:id', (req, res) => {
  const { phone = '' } = req.query;
  const order = readStore().orders.find(o => o.id === req.params.id && o.customer.phone === phone);
  if (!order) return res.status(404).json({ error: 'Order not found. Check the order ID and phone number.' });
  res.json(order);
});
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  if (email === 'admin@novamobile.test' && password === 'Nova@2026') return res.json({ token: 'smartzone-demo-admin' });
  res.status(401).json({ error: 'Invalid admin credentials.' });
});
function isAdmin(req, res, next) {
  if (req.headers.authorization !== 'Bearer smartzone-demo-admin') return res.status(401).json({ error: 'Admin login required.' });
  next();
}
app.get('/api/admin/orders', isAdmin, (req, res) => res.json(readStore().orders));
app.post('/api/admin/products', isAdmin, (req, res) => {
  const { name, brand, category, price, stock, image, description, tag } = req.body;
  if (!name || !brand || !category || !(Number(price) > 0)) return res.status(400).json({ error: 'Name, brand, category and valid price are required.' });
  const store = readStore();
  const product = { id: makeId('P-'), name, brand, category, price: Number(price), stock: Math.max(0, Number(stock) || 0), image: image || '', description: description || '', tag: tag || 'New' };
  store.products.unshift(product);
  writeStore(store);
  res.status(201).json(product);
});
app.patch('/api/admin/orders/:id', isAdmin, (req, res) => {
  const store = readStore();
  const order = store.orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const allowed = ['Order Placed', 'Confirmed', 'Packed', 'Shipped', 'Delivered', 'Cancelled'];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: 'Invalid status.' });
  order.status = req.body.status;
  writeStore(store);
  res.json(order);
});

app.post('/api/service-requests', (req, res) => {
  const { name, phone, service, model, details } = req.body;
  if (!name || !phone || !service) return res.status(400).json({ error: 'Name, phone and service are required.' });
  const store = readStore();
  store.serviceRequests = store.serviceRequests || [];
  const request = { id: makeId('SR-'), name, phone, service, model: model || '', details: details || '', status: 'Received', createdAt: new Date().toISOString() };
  store.serviceRequests.unshift(request);
  writeStore(store);
  res.status(201).json({ request });
});
app.post('/api/contact', (req, res) => {
  const { name, email, phone, subject, message } = req.body;
  if (!name || !email || !message) return res.status(400).json({ error: 'Name, email and message are required.' });
  const store = readStore();
  store.contactMessages = store.contactMessages || [];
  const item = { id: makeId('MSG-'), name, email, phone: phone || '', subject: subject || 'General enquiry', message, createdAt: new Date().toISOString() };
  store.contactMessages.unshift(item);
  writeStore(store);
  res.status(201).json({ message: 'Your message has been received.', id: item.id });
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html')));
app.listen(PORT, () => console.log(`SmartZone running at http://localhost:${PORT}`));

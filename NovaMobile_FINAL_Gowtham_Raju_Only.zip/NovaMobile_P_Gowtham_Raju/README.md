# NovaMobile — Advanced Mobile Store Demo

A distinct responsive full-stack mobile shopping website with a premium dark + lime visual identity.

## Automatic start on Windows
1. Extract the ZIP.
2. Open the extracted `NovaMobile_P_Gowtham_Raju` folder.
3. Double-click `START_NOVAMOBILE.bat`.
4. First run installs packages, starts the server and opens http://localhost:5000.
5. Keep the terminal window open while using the site.

Node.js 18 or newer is required. Install from https://nodejs.org/ if needed.

## Pages and features
Home/catalogue, product details, cart, checkout, order tracking, admin dashboard, founder/about, Nova Care+ service requests, compare devices, wishlist, contact and FAQ. Search, category filters and price sorting are included.

## Founder
Founder: P. Gowtham Raju. His supplied photograph is displayed on the homepage and About page.

## Demo admin
Email: admin@novamobile.test
Password: Nova@2026

Demo only: no real payment gateway is connected. Orders and service/contact requests are stored locally in backend/data/store.json.

@echo off
title NovaMobile Store - Automatic Setup
cd /d "%~dp0"
echo ==========================================
echo             NOVAMOBILE STORE
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js 18 or newer is required.
 echo Install it from https://nodejs.org/ and run this file again.
 pause
 exit /b 1
)
if not exist node_modules (
 echo Installing required packages...
 call npm install
 if errorlevel 1 (echo Installation failed. Check internet and retry.& pause & exit /b 1)
)
echo Opening NovaMobile in your browser...
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:5000"
echo Keep this window open while using the site.
call npm start
pause
